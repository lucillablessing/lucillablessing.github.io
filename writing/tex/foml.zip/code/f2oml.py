from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum, auto
from typing import Callable, Self
import re


class OL(ABC):

	@abstractmethod
	def __and__(a: Self, b: Self) -> Self:  # `&` symbol, meet operation
		pass
	
	@abstractmethod
	def __or__(a: Self, b: Self)  -> Self:  # `|` symbol, join operation
		pass
	
	@abstractmethod
	def __invert__(s: Self) -> Self:        # `~` symbol, orthocomplement
		pass
	
	@abstractmethod
	def zero() -> Self:  # zero element
		pass
	
	@abstractmethod
	def unit() -> Self:  # unit element
		pass

	def upcom(a: Self, b: Self) -> Self:
		return (a | b) & (a | ~b) & (~a | b) & (~a | ~b)

	def mo2_a(a: Self, b: Self) -> Self:
		return  a & (~a | b) & (~a | ~b)

	def mo2_b(a: Self, b: Self) -> Self:
		return  b & (~b | a) & (~b | ~a)

	def mo2_A(a: Self, b: Self) -> Self:
		return ~a & ( a | b) & ( a | ~b)

	def mo2_B(a: Self, b: Self) -> Self:
		return ~b & ( b | a) & ( b | ~a)


class MetaEnum(type(Enum), type(OL)):
	pass


@dataclass(eq = False, frozen = True)
class MO2(OL, Enum, metaclass=MetaEnum):
	# the order of the elements matches the order
	# in which they should appear in the operation tables;
	# zero first, unit last, orthocomplements opposite
	O = auto()
	a = auto()
	b = auto()
	B = auto()
	A = auto()
	I = auto()
	
	def __and__(a: Self, b: Self) -> Self:
		match (a, b):
			case (MO2.O, _):       return MO2.O  #  0 & x = 0
			case (_, MO2.O):       return MO2.O  #  x & 0 = 0
			case (x, MO2.I):       return x      #  x & 1 = x
			case (MO2.I, y):       return y      #  1 & y = y
			case (x, y) if x == y: return x      #  x & x = x
			case (_, _):           return MO2.O  #  x & y = 0 in all other cases
	
	def __or__(a: Self, b: Self)  -> Self:
		match (a, b):
			case (MO2.I, _):       return MO2.I  #  1 | y = 1
			case (_, MO2.I):       return MO2.I  #  x | 1 = 1
			case (x, MO2.O):       return x      #  x | 0 = x
			case (MO2.O, y):       return y      #  0 | y = y
			case (x, y) if x == y: return x      #  x | x = x
			case (_, _):           return MO2.I  #  x | y = 1 in all other cases
	
	def __invert__(s: Self) -> Self:
		match s:
			case MO2.O: return MO2.I  #  0' = 1
			case MO2.a: return MO2.A  #  a' = A
			case MO2.b: return MO2.B  #  b' = B
			case MO2.B: return MO2.b  #  B' = b
			case MO2.A: return MO2.a  #  A' = a
			case MO2.I: return MO2.O  #  1' = 0
	
	def zero() -> Self: return MO2.O
	def unit() -> Self: return MO2.I

	def __str__(s: Self) -> str:
		match s:
			case MO2.O: return "0"
			case MO2.a: return "a"
			case MO2.b: return "b"
			case MO2.B: return "B"
			case MO2.A: return "A"
			case MO2.I: return "1"
			



@dataclass
class F2OML(OL):
	u: bool = False
	d: bool = False
	l: bool = False
	r: bool = False
	m: MO2  = MO2.O

	def __and__(a: Self, b: Self) -> Self:
		return F2OML(a.u & b.u, a.d & b.d, a.l & b.l, a.r & b.r, a.m & b.m)
	
	def __or__(a: Self, b: Self)  -> Self:
		return F2OML(a.u | b.u, a.d | b.d, a.l | b.l, a.r | b.r, a.m | b.m)
	
	def __invert__(s: Self) -> Self:
		return F2OML(not s.u, not s.d, not s.l, not s.r, ~s.m)
	
	def zero() -> Self:
		return F2OML(False, False, False, False, MO2.zero())
	
	def unit() -> Self:
		return F2OML(True,  True,  True,  True,  MO2.unit())

	def __str__(s: Self) -> str:
		t = str(s.m)
		if s.l: t += "l"
		if s.u: t += "u"
		if s.d: t += "d"
		if s.r: t += "r"
		return t
	
	def parse(t: str) -> Self:
		# Parse an F2OML string into an F2OML object
		p = re.compile("(0|1|a|A|b|B)?(l?)(u?)(d?)(r?)$")
		q = p.match(t)
		if q is None: raise ValueError(f'Invalid F2OML string: "{t}"')
		match q.group(1):
			case "0": m = MO2.O
			case "1": m = MO2.I
			case "a": m = MO2.a
			case "A": m = MO2.A
			case "b": m = MO2.b
			case "B": m = MO2.B
		l = bool(q.group(2))
		u = bool(q.group(3))
		d = bool(q.group(4))
		r = bool(q.group(5))
		return F2OML(u, d, l, r, m)


def draw_table_mo2(f: Callable[[OL, OL], OL]):
	# Draws an operator table for the binary operation f in MO2.
	print("\n", end = "")
	print(f"   \u2502", end = "")
	for j in MO2:
		print(f" {j} ", end = "")
	print("\n\u2500\u2500\u2500\u253C", end = "")
	for _ in MO2:
		print("\u2500\u2500\u2500", end = "")
	print("\n", end = "")
	for i in MO2:
		print(f" {i} \u2502", end = "")
		for j in MO2:
			print(f" {f(i, j)} ", end = "")
		print("\n   \u2502\n", end = "")


def triplex(x: str, y: str, z: str) -> str:
	# Evaluates the triplex symbol "x y z".
	# Parses x, y, z as three F2OML strings.
	# Returns the F2OML string of x y z.
	f_x = F2OML.parse(x)
	f_y = F2OML.parse(y)
	f_z = F2OML.parse(z)
	out = F2OML.zero()
	if f_y.d: out |=  f_x &  f_z
	if f_y.l: out |=  f_x & ~f_z
	if f_y.r: out |= ~f_x &  f_z
	if f_y.u: out |= ~f_x & ~f_z
	match f_y.m:
		case MO2.O: f_m = F2OML.zero()
		case MO2.I: f_m = F2OML.upcom(f_x, f_z)
		case MO2.a: f_m = F2OML.mo2_a(f_x, f_z)
		case MO2.A: f_m = F2OML.mo2_A(f_x, f_z)
		case MO2.b: f_m = F2OML.mo2_b(f_x, f_z)
		case MO2.B: f_m = F2OML.mo2_B(f_x, f_z)
	return str(out | f_m)


#print(triplex("ald", "Aldr", "bdr"))

#draw_table_mo2(MO2.mo2_a)
draw_table_mo2(MO2.mo2_b)
#draw_table_mo2(MO2.mo2_A)
#draw_table_mo2(MO2.mo2_B)
#draw_table_mo2(MO2.upcom)